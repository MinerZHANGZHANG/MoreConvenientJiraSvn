﻿using System.Windows.Controls;

namespace MoreConvenientJiraSvn.Gui.View.Pages
{
    /// <summary>
    /// PluginSettingPage.xaml 的交互逻辑
    /// </summary>
    public partial class PluginSettingPage : Page
    {
        public PluginSettingPage()
        {
            InitializeComponent();
        }
    }
}
